# *.h files generated running `HFacer.py` in the `scintilla/include` folder:
cd scintilla/include && python HFacer.py
